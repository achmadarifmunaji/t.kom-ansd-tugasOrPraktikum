def binary_search(names, target_name):
    low = 0
    high = len(names) - 1

    while low <= high:
        mid = (low + high) // 2
        mid_name = names[mid]

        if mid_name == target_name:
            return mid
        elif mid_name < target_name:
            low = mid + 1
        else:
            high = mid - 1

    return -1  # Nama barang tidak ditemukan

# Daftar nama barang yang diurutkan (contoh)
names = [
    "Barang A", "Barang B", "Barang C", "Barang D", "Barang E",
    "Barang F", "Barang G", "Barang H", "Barang I", "Barang J",
    "Barang K", "Barang L", "Barang M", "Barang N", "Barang O",
    "Barang P", "Barang Q", "Barang R", "Barang S", "Barang T",
    "Barang U", "Barang V", "Barang W", "Barang X", "Barang Y",
    "Barang Z", "Barang AA", "Barang AB", "Barang AC", "Barang AD",
    "Barang AE", "Barang AF", "Barang AG", "Barang AH", "Barang AI",
    "Barang AJ", "Barang AK", "Barang AL", "Barang AM", "Barang AN",
    "Barang AO", "Barang AP", "Barang AQ", "Barang AR", "Barang AS",
    "Barang AT", "Barang AU", "Barang AV", "Barang AW", "Barang AX",
]

target_name = "Barang X"  # Gantilah ini dengan nama barang yang ingin Anda cari
result = binary_search(names, target_name)

if result != -1:
    print(f"{target_name} ditemukan pada indeks {result}")
else:
    print(f"{target_name} tidak ditemukan dalam daftar barang")