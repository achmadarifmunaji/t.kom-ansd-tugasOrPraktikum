def linear_search(names, target_name):
    for i in range(len(names)):
        if names[i] == target_name:
            return i
    return -1  # Nama barang tidak ditemukan

# Daftar 200 nama barang dalam bentuk array
nama_barang = [
    "Barang A", "Barang B", "Barang C", "Barang D", "Barang E",
    "Barang F", "Barang G", "Barang H", "Barang I", "Barang J",
    "Barang K", "Barang L", "Barang M", "Barang N", "Barang O",
    "Barang P", "Barang Q", "Barang R", "Barang S", "Barang T",
    "Barang U", "Barang V", "Barang W", "Barang X", "Barang Y",
    "Barang Z", "Barang AA", "Barang AB", "Barang AC", "Barang AD",
    "Barang AE", "Barang AF", "Barang AG", "Barang AH", "Barang AI",
    "Barang AJ", "Barang AK", "Barang AL", "Barang AM", "Barang AN",
    "Barang AO", "Barang AP", "Barang AQ", "Barang AR", "Barang AS",
    "Barang AT", "Barang AU", "Barang AV", "Barang AW", "Barang AX",
    "Barang AY", "Barang AZ", "Barang BA", "Barang BB", "Barang BC",
    "Barang BD", "Barang BE", "Barang BF", "Barang BG", "Barang BH",
    "Barang BI", "Barang BJ", "Barang BK", "Barang BL", "Barang BM",
    "Barang BN", "Barang BO", "Barang BP", "Barang BQ", "Barang BR",
    "Barang BS", "Barang BT", "Barang BU", "Barang BV", "Barang BW",
    "Barang BX", "Barang BY", "Barang BZ", "Barang CA", "Barang CB",
    "Barang CC", "Barang CD", "Barang CE", "Barang CF", "Barang CG",
    "Barang CH", "Barang CI", "Barang CJ", "Barang CK", "Barang CL",
    "Barang CM", "Barang CN", "Barang CO", "Barang CP", "Barang CQ",
    "Barang CR", "Barang CS", "Barang CT", "Barang CU", "Barang CV",
    "Barang CW", "Barang CX", "Barang CY", "Barang CZ", "Barang DA",
    "Barang DB", "Barang DC", "Barang DD", "Barang DE", "Barang DF",
    "Barang DG", "Barang DH", "Barang DI", "Barang DJ", "Barang DK",
    "Barang DL", "Barang DM", "Barang DN", "Barang DO", "Barang DP",
    "Barang DQ", "Barang DR", "Barang DS", "Barang DT", "Barang DU",
    "Barang DV", "Barang DW", "Barang DX", "Barang DY", "Barang DZ",
    "Barang EA", "Barang EB", "Barang EC", "Barang ED", "Barang EE",
    "Barang EF", "Barang EG", "Barang EH", "Barang EI", "Barang EJ",
    "Barang EK", "Barang EL", "Barang EM", "Barang EN", "Barang EO",
    "Barang EP", "Barang EQ", "Barang ER", "Barang ES", "Barang ET",
    "Barang EU", "Barang EV", "Barang EW", "Barang EX", "Barang EY",
    "Barang EZ", "Barang FA", "Barang FB", "Barang FC", "Barang FD",
    "Barang FE", "Barang FF", "Barang FG", "Barang FH", "Barang FI",
    "Barang FJ", "Barang FK", "Barang FL", "Barang FM", "Barang FN",
    "Barang FO", "Barang FP", "Barang FQ", "Barang FR", "Barang FS",
    "Barang FT", "Barang FU", "Barang FV", "Barang FW", "Barang FX",
    "Barang FY", "Barang FZ", "Barang GA", "Barang GB", "Barang GC",
    "Barang GD", "Barang GE", "Barang GF", "Barang GG", "Barang GH",
    "Barang GI", "Barang GJ", "Barang GK", "Barang GL", "Barang GM",
    "Barang GN", "Barang GO", "Barang GP", "Barang GQ", "Barang GR",
]

target_name = "Barang GO"  # Gantilah ini dengan nama barang yang ingin Anda cari
result = linear_search(nama_barang, target_name)

if result != -1:
    print(f"{target_name} ditemukan pada indeks {result}")
else:
    print(f"{target_name} tidak ditemukan dalam daftar barang")
