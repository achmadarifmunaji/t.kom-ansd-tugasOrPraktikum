def linear_search(names, target_name):
    for i in range(len(names)):
        if names[i] == target_name:
            return i
    return -1  # Nama barang tidak ditemukan

# Daftar 200 nama barang dalam bentuk array
nama_barang = [
    "Barang A", "Barang B", "Barang C", "Barang D", "Barang E",
    "Barang F", "Barang G", "Barang H", "Barang I", "Barang J",
    "Barang K", "Barang L", "Barang M", "Barang N", "Barang O",
    "Barang P", "Barang Q", "Barang R", "Barang S", "Barang T",
    "Barang U", "Barang V", "Barang W", "Barang X", "Barang Y",
    "Barang Z", "Barang AA", "Barang AB", "Barang AC", "Barang AD",
    "Barang AE", "Barang AF", "Barang AG", "Barang AH", "Barang AI",
    "Barang AJ", "Barang AK", "Barang AL", "Barang AM", "Barang AN",
    "Barang AO", "Barang AP", "Barang AQ", "Barang AR", "Barang AS",
    "Barang AT", "Barang AU", "Barang AV", "Barang AW", "Barang AX",
    
]

target_name = "Barang X"  # Gantilah ini dengan nama barang yang ingin Anda cari
result = linear_search(nama_barang, target_name)

if result != -1:
    print(f"{target_name} ditemukan pada indeks {result}")
else:
    print(f"{target_name} tidak ditemukan dalam daftar barang")