def binary_search(books, target):
    low = 0
    high = len(books) - 1

    while low <= high:
        mid = (low + high) // 2
        mid_book = books[mid]

        if mid_book == target:
            return mid
        elif mid_book < target:
            low = mid + 1
        else:
            high = mid - 1

    return -1  # Buku tidak ditemukan

# Daftar 200 nama buku yang diurutkan secara alfabetis
books = [
    "Jejak Kehidupan di Palangkaraya: Sebuah Kenangan",
    "Eksplorasi Hutan Tropis di Palangkaraya",
    "Kisah Anak-anak Palangkaraya: Impian dan Harapan",
    "Bunga Raya Palangkaraya: Keindahan Tumbuhan Tropis",
    "Palangkaraya: Kota di Tengah Hutan Kalimantan",
    "Seni Tari Tradisional Dayak Palangkaraya",
    "Makanan Khas Palangkaraya: Enaknya Kuliner Nusantara",
    "Palangkaraya: Kota Bertata Air dan Darat",
    "Pusaka Seni dan Budaya Dayak",
    "Kebijakan Kesehatan di Palangkaraya: Kesejahteraan Masyarakat",
    "Jejak Kehidupan di Palangkaraya: Sebuah Kenangan",
    "Eksplorasi Hutan Tropis di Palangkaraya",
    "Kisah Anak-anak Palangkaraya: Impian dan Harapan",
    "Bunga Raya Palangkaraya: Keindahan Tumbuhan Tropis",
    "Palangkaraya: Kota di Tengah Hutan Kalimantan",
    "Seni Tari Tradisional Dayak Palangkaraya",
    "Makanan Khas Palangkaraya: Enaknya Kuliner Nusantara",
    "Palangkaraya: Kota Bertata Air dan Darat",
    "Pusaka Seni dan Budaya Dayak",
    "Petualangan di Sungai Kahayan: Menjelajahi Keindahan Alam Kalimantan",
    "Sejarah Palangkaraya: Dari Desa ke Kota",
    "Palangkaraya: Menyelami Sungai Kahayan",
    "Bisnis di Palangkaraya: Potensi dan Tantangan",
    "Palangkaraya: Melihat Dunia dari Tengah Pulau Kalimantan",
    "Seni Beladiri Dayak: Warisan Tradisi",
    "Masyarakat Dayak: Kebudayaan dan Identitas",
    "Surga Burung di Palangkaraya: Melihat Keanekaragaman Burung",
    "Kehidupan Sungai Kahayan: Keajaiban Alam Kalimantan",
    "Palangkaraya: Jembatan Budaya Dayak",
    "Eksplorasi Hutan Hujan Kalimantan: Petualangan di Hutan Tropis",
    "Palangkaraya: Memahami Kearifan Lokal",
    "Ragam Flora dan Fauna di Kalimantan Tengah",
    "Palangkaraya: Kota Toleransi dan Keberagaman",
    "Dayak: Tradisi dan Ritual dalam Kehidupan Sehari-hari",
    "Palangkaraya: Perjalanan melintasi Kalimantan Tengah",
    "Seni Lukis Dayak: Keindahan di Atas Kanvas",
    "Pantai Pasir: Liburan di Sekitar Palangkaraya",
    "Palangkaraya: Kesejahteraan di Tengah Hutan",
    "Sejarah Kehidupan Dayak: Jejak Masyarakat Asli Kalimantan",
    "Pusaka Budaya Dayak: Nilai dan Tradisi Leluhur",
    "Kalimantan Tengah: Keindahan Keanekaragaman Alam",
    "Mengenal Pohon-pohon di Palangkaraya: Petualangan Alam",
    "Palangkaraya: Kota dengan Seribu Cerita",
    "Lingkungan Hidup di Kalimantan: Pelestarian Sumber Daya Alam",
    "Seni Tari Dayak: Gerakan dan Makna",
    "Palangkaraya: Berlayar di Sungai Kahayan",
    "Masyarakat Dayak: Keberagaman Kebudayaan",
    "Pakaian Adat Dayak: Simbol Identitas",
    "Sekolah di Palangkaraya: Pendidikan dan Perubahan",
    "Palangkaraya: Keindahan Taman Kota"
]

target_book ="Seni Tari Dayak: Gerakan dan Makna"  # Gantilah ini dengan nama buku yang ingin Anda cari
result = binary_search(books, target_book)

if result != -1:
    print(f"{target_book} ditemukan pada indeks {result}")
else:
    print(f"{target_book} tidak ditemukan dalam daftar buku")