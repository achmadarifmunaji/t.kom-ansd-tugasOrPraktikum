# #data_kecil

# def binary_search(contacts, name):
#     low = 0
#     high = len(contacts) - 1

#     while low <= high:
#         mid = (low + high) // 2
#         if contacts[mid]["nama"] == name:
#             return contacts[mid]
#         elif contacts[mid]["nama"] < name:
#             low = mid + 1
#         else:
#             high = mid - 1

#     return None

# contacts = [
#     {"nama": "Abimayu Cendric", "telp": "0811432576100", "email": "abimayucendric@example.com"},
# {"nama": "Adira Fairuz", "telp": "0876346113", "email": "adirafairuz@example.com"},
# {"nama": "Aditya Pratama", "telp": "087549360152", "email": "adityapratama@example.com"},
# {"nama": "Adnan Owen", "telp": "0845317115", "email": "adnanowen@example.com"},
# {"nama": "Agni Geeta", "telp": "086543568795", "email": "agnigeeta@example.com"},
# {"nama": "Agus Santoso", "telp": "087694062154", "email": "agussantoso@example.com"},
# {"nama": "Agus Setiawan", "telp": "089012345678", "email": "agussetiawan@example.com"},
# {"nama": "Ahmad Farhan", "telp": "084376889175", "email": "ahmadfarhan@example.com"},
# {"nama": "Ahmad Khaled", "telp": "081423567118", "email": "ahmadkhaled@example.com"},
# {"nama": "Aiden Edwin", "telp": "082365431287", "email": "edwinaiden@example.com"},
# {"nama": "Aksa Owais", "telp": "085643218792", "email": "aksaowais@example.com"},
# {"nama": "Alexander Davis", "telp": "103678912345", "email": "alexanderdavis@example.com"},
# {"nama": "Alexander Johnson", "telp": "135934567891", "email": "alexanderjohnson@example.com"},
# {"nama": "Alexander Wilson", "telp": "109345678912", "email": "alexanderwilson@example.com"},
# {"nama": "Alinea Utami", "telp": "087654908136", "email": "alineautami@example.com"},
# {"nama": "Amelia Rodriguez", "telp": "125923456789", "email": "ameliarodriguez@example.com"},
# {"nama": "Amelia Wilson", "telp": "100345678912", "email": "ameliawilson@example.com"},
# {"nama": "Amira Elfreda", "telp": "081567894679", "email": "amiraelfreda@example.com"},
# {"nama": "Ahmad Prasetyo", "telp": "085678901234", "email": "ahmadprasetyo@example.com"},
# {"nama": "Andi Pratama", "telp": "085869756187", "email": "andipratama@example.com"},
# {"nama": "Andrew Martinez", "telp": "093567891234", "email": "andrewmartinez@example.com"},
# {"nama": "Ani Wulandari", "telp": "082345678901", "email": "aniwulandari@example.com"},
# {"nama": "Anna Mesha", "telp": "08543216105", "email": "annamesha@example.com"},
# {"nama": "Anwar Harahap", "telp": "0823145326169", "email": "anwarharahap@example.com"},
# {"nama": "Arief Budiman", "telp": "086754328164", "email": "ariefbudiman@example.com"},
# {"nama": "Arya Putra", "telp": "089769547196", "email": "aryaputra@example.com"},
# {"nama": "Arzan Gevariel", "telp": "087968543131", "email": "arzangevariel@example.com"},
# {"nama": "Aswin Uttam", "telp": "082365431896", "email": "aswinuttam@example.com"},
# {"nama": "Athifa Prisa", "telp": "082365471282", "email": "prisaathifa@example.com"},
# {"nama": "Atika Fithriya", "telp": "085643219084", "email": "fithriyaatika@example.com"},
# {"nama": "Ava Garcia", "telp": "092456789123", "email": "avagarcia@example.com"},
# {"nama": "Ava Martinez", "telp": "121578912345", "email": "avamartinez@example.com"},
# {"nama": "Ava Thomas", "telp": "110456789123", "email": "avathomas@example.com"},
# {"nama": "Awan Utami", "telp": "082364769138", "email": "awanutami@example.com"},
# {"nama": "Aymaan Hishal", "telp": "084328289120", "email": "aymaanhishal@example.com"},
# {"nama": "Ayu Lestari", "telp": "083950937184", "email": "ayulestari@example.com"},
# {"nama": "Ayu Rahmawati", "telp": "09890123456", "email": "ayu@example.com"},
# {"nama": "Baasim Ghava", "telp": "0813241116", "email": "baasimghava@example.com"},
# {"nama": "Bambang Santoso", "telp": "089890123456", "email": "bambangsantoso@example.com"},
# {"nama": "Bambang Santoso", "telp": "082354279177", "email": "bambangsantoso@example.com"},
# {"nama": "Benjamin Garcia", "telp": "124812345678", "email": "benjamingarcia@example.com"},
# {"nama": "Benjamin Rodriguez", "telp": "113789123456", "email": "benjaminrodriguez@example.com"},
# {"nama": "Benjamin Thomas", "telp": "101456789123", "email": "benjaminthomas@example.com"},
# {"nama": "Bintang Juang", "telp": "089750463137", "email": "bintangjuang@example.com"},
# {"nama": "Bora Deepti", "telp": "083865462103", "email": "boradeepti@example.com"},
# {"nama": "Budi Santoso", "telp": "081234567890", "email": "budisantoso@example.com"},
# {"nama": "Budi Susanto", "telp": "087439270150", "email": "budisusanto@example.com"},
# {"nama": "Catra Arnawama", "telp": "081743215692", "email": "catraarnawama@exampl,e.com"},
# {"nama": "Charlotte Davis", "telp": "129367891234", "email": "charlottedavis@example.com"},
# {"nama": "Charlotte Garcia", "telp": "102567891234", "email": "charlottegarcia@example.com"},
# ]

# nama_cari = input("Masukkan nama yang ingin dicari: ")
# hasil_pencarian = binary_search(contacts, nama_cari)

# if hasil_pencarian:
#     print("Data kontak ditemukan:")
#     print("Nama:", hasil_pencarian["nama"])
#     print("Telepon:", hasil_pencarian["telp"])
#     print("Email:", hasil_pencarian["email"])
# else:
#     print("Data kontak tidak ditemukan.")




#data besar

def binary_search(contacts, name):
    low = 0
    high = len(contacts) - 1

    while low <= high:
        mid = (low + high) // 2
        if contacts[mid]["nama"] == name:
            return contacts[mid]
        elif contacts[mid]["nama"] < name:
            low = mid + 1
        else:
            high = mid - 1

    return None

contacts = [
{"nama": "Abimayu Cendric", "telp": "0811432576100", "email": "abimayucendric@example.com"},
{"nama": "Adira Fairuz", "telp": "0876346113", "email": "adirafairuz@example.com"},
{"nama": "Aditya Pratama", "telp": "087549360152", "email": "adityapratama@example.com"},
{"nama": "Adnan Owen", "telp": "0845317115", "email": "adnanowen@example.com"},
{"nama": "Agni Geeta", "telp": "086543568795", "email": "agnigeeta@example.com"},
{"nama": "Agus Santoso", "telp": "087694062154", "email": "agussantoso@example.com"},
{"nama": "Agus Setiawan", "telp": "089012345678", "email": "agussetiawan@example.com"},
{"nama": "Ahmad Farhan", "telp": "084376889175", "email": "ahmadfarhan@example.com"},
{"nama": "Ahmad Khaled", "telp": "081423567118", "email": "ahmadkhaled@example.com"},
{"nama": "Aiden Edwin", "telp": "082365431287", "email": "edwinaiden@example.com"},
{"nama": "Aksa Owais", "telp": "085643218792", "email": "aksaowais@example.com"},
{"nama": "Alexander Davis", "telp": "103678912345", "email": "alexanderdavis@example.com"},
{"nama": "Alexander Johnson", "telp": "135934567891", "email": "alexanderjohnson@example.com"},
{"nama": "Alexander Wilson", "telp": "109345678912", "email": "alexanderwilson@example.com"},
{"nama": "Alinea Utami", "telp": "087654908136", "email": "alineautami@example.com"},
{"nama": "Amelia Rodriguez", "telp": "125923456789", "email": "ameliarodriguez@example.com"},
{"nama": "Amelia Wilson", "telp": "100345678912", "email": "ameliawilson@example.com"},
{"nama": "Amira Elfreda", "telp": "081567894679", "email": "amiraelfreda@example.com"},
{"nama": "Ahmad Prasetyo", "telp": "085678901234", "email": "ahmadprasetyo@example.com"},
{"nama": "Andi Pratama", "telp": "085869756187", "email": "andipratama@example.com"},
{"nama": "Andrew Martinez", "telp": "093567891234", "email": "andrewmartinez@example.com"},
{"nama": "Ani Wulandari", "telp": "082345678901", "email": "aniwulandari@example.com"},
{"nama": "Anna Mesha", "telp": "08543216105", "email": "annamesha@example.com"},
{"nama": "Anwar Harahap", "telp": "0823145326169", "email": "anwarharahap@example.com"},
{"nama": "Arief Budiman", "telp": "086754328164", "email": "ariefbudiman@example.com"},
{"nama": "Arya Putra", "telp": "089769547196", "email": "aryaputra@example.com"},
{"nama": "Arzan Gevariel", "telp": "087968543131", "email": "arzangevariel@example.com"},
{"nama": "Aswin Uttam", "telp": "082365431896", "email": "aswinuttam@example.com"},
{"nama": "Athifa Prisa", "telp": "082365471282", "email": "prisaathifa@example.com"},
{"nama": "Atika Fithriya", "telp": "085643219084", "email": "fithriyaatika@example.com"},
{"nama": "Ava Garcia", "telp": "092456789123", "email": "avagarcia@example.com"},
{"nama": "Ava Martinez", "telp": "121578912345", "email": "avamartinez@example.com"},
{"nama": "Ava Thomas", "telp": "110456789123", "email": "avathomas@example.com"},
{"nama": "Awan Utami", "telp": "082364769138", "email": "awanutami@example.com"},
{"nama": "Aymaan Hishal", "telp": "084328289120", "email": "aymaanhishal@example.com"},
{"nama": "Ayu Lestari", "telp": "083950937184", "email": "ayulestari@example.com"},
{"nama": "Ayu Rahmawati", "telp": "09890123456", "email": "ayu@example.com"},
{"nama": "Baasim Ghava", "telp": "0813241116", "email": "baasimghava@example.com"},
{"nama": "Bambang Santoso", "telp": "089890123456", "email": "bambangsantoso@example.com"},
{"nama": "Bambang Santoso", "telp": "082354279177", "email": "bambangsantoso@example.com"},
{"nama": "Benjamin Garcia", "telp": "124812345678", "email": "benjamingarcia@example.com"},
{"nama": "Benjamin Rodriguez", "telp": "113789123456", "email": "benjaminrodriguez@example.com"},
{"nama": "Benjamin Thomas", "telp": "101456789123", "email": "benjaminthomas@example.com"},
{"nama": "Bintang Juang", "telp": "089750463137", "email": "bintangjuang@example.com"},
{"nama": "Bora Deepti", "telp": "083865462103", "email": "boradeepti@example.com"},
{"nama": "Budi Santoso", "telp": "081234567890", "email": "budisantoso@example.com"},
{"nama": "Budi Susanto", "telp": "087439270150", "email": "budisusanto@example.com"},
{"nama": "Catra Arnawama", "telp": "081743215692", "email": "catraarnawama@exampl,e.com"},
{"nama": "Charlotte Davis", "telp": "129367891234", "email": "charlottedavis@example.com"},
{"nama": "Charlotte Garcia", "telp": "102567891234", "email": "charlottegarcia@example.com"},
{"nama": "Christopher Lee", "telp": "087891234567", "email": "christopherlee@example.com"},
{"nama": "Cia Kishika", "telp": "081245327112", "email": "ciakishika@example.com"},
{"nama": "Citra Sari", "telp": "10789012345", "email": "citra@example.com"},
{"nama": "Cindy Adira", "telp": "08769088786", "email": "adiracindy@example.com"},
{"nama": "Dafhina", "telp": "085277652101", "email": "dafhina@example.com"},
{"nama": "Daniel Davis", "telp": "133712345678", "email": "danieldavis@example.com"},
{"nama": "Daniel Taylor", "telp": "107123456789", "email": "danieltaylor@example.com"},
{"nama": "Daniel Wilson", "telp": "089123456789", "email": "danielwilson@example.com"},
{"nama": "Dara Sekar", "telp": "08795964130", "email": "darasekar@example.com"},
{"nama": "Darmawan Wijaya", "telp": "085648793193", "email": "darmawanwijaya@example.com"},
{"nama": "Darrel Atara", "telp": "087960547140", "email": "darrelatara@example.com"},
{"nama": "David Brown", "telp": "085678912345", "email": "davidbrown@example.com"},
{"nama": "Dedy Prasetyo", "telp": "082765497179", "email": "dedyprasetyo@example.com"},
{"nama": "Dharma Wijaya", "telp": "10890123456", "email": "dharma@example.com"},
{"nama": "Desi Anggraeni", "telp": "083427685174", "email": "desianggraeni@example.com"},
{"nama": "Desi Putri", "telp": "089123456789", "email": "desiputri@example.com"},
{"nama": "Devi Fitriani", "telp": "084365782188", "email": "devifitriani@example.com"},
{"nama": "Dian Sari", "telp": "089740230156", "email": "diansari@example.com"},
{"nama": "Dian Suryanto", "telp": "087890123456", "email": "diansuryanto@example.com"},
{"nama": "Dimas Farraz", "telp": "085641236594", "email": "dimasfarraz@example.com"},
{"nama": "Dwi Nugroho", "telp": "089678901234", "email": "dwinugroho@example.com"},
{"nama": "Dwi Setiawan", "telp": "087765243171", "email": "dwisetiawan@example.com"},
{"nama": "Eka Wijaya", "telp": "081734650167", "email": "ekawijaya@example.com"},
{"nama": "Eko Wibowo", "telp": "089456789012", "email": "ekowibowo@example.com"},
{"nama": "Embun Dwiryasti", "telp": "085847084139", "email": "embundwiryasti@example.com"},
{"nama": "Emilio Nizar", "telp": "0877987685", "email": "nizaremilio@example.com"},
{"nama": "Emily Anderson", "telp": "090234567891", "email": "emilyanderson@example.com"},
{"nama": "Emily Garcia", "telp": "132691234567", "email": "emilygarcia@example.com"},
{"nama": "Emma Brown", "telp": "119356789123", "email": "emmabrown@example.com"},
{"nama": "Ender Ahsa", "telp": "0845636122", "email": "enderahsa@example.com"},
{"nama": "Esha Farras", "telp": "081254360898", "email": "eshafarras@example.com"},
{"nama": "Ethan Anderson", "telp": "122689123456", "email": "ethananderson@example.com"},
{"nama": "Ethan Brown", "telp": "099234567891", "email": "ethanbrown@example.com"},
{"nama": "Eva Adiratna", "telp": "11489187977", "email": "adiratnaeva@example.com"},
{"nama": "Eva Celia", "telp": "082574390134", "email": "evacelia@example.com"},
{"nama": "Evelyn Anderson", "telp": "106912345678", "email": "evelynanderson@example.com"},
{"nama": "Fauzi Abdullah", "telp": "089705874157", "email": "fauziabdullah@example.com"},
{"nama": "Ferdi Prasetyo", "telp": "086758437198", "email": "ferdiprasetyo@example.com"},
{"nama": "Fitri Utami", "telp": "082457293178", "email": "fitriutami@example.com"},
{"nama": "Freya Gresheilla", "telp": "085648739141", "email": "freagresheilla@example.com"},
{"nama": "Gea Utari", "telp": "087765458147", "email": "geautari@example.com"},
{"nama": "Gina Reeya", "telp": "081265432121", "email": "ginareeya@example.com"},
{"nama": "Hadi Surya", "telp": "084659380162", "email": "hadisurya@example.com"},
{"nama": "Haidar Keenan", "telp": "085832754111", "email": "haidarkeenan@example.com"},
{"nama": "Haina Hanam", "telp": "0879654123", "email": "hainahanam@example.com"},
{"nama": "Hana Setiawan", "telp": "081527635197", "email": "hanasetiawan@example.com"},
{"nama": "Hans Gunarma", "telp": "084839659145", "email": "hansgunarma@example.com"},
{"nama": "Hendriawan Wijaya", "telp": "09789012345", "email": "hendriawan@example.com"},
{"nama": "Harper Rodriguez", "telp": "104789123456", "email": "harperrodriguez@example.com"},
{"nama": "Harper Taylor", "telp": "131589123456", "email": "harpertaylor@example.com"},
{"nama": "Henry Johnson", "telp": "126034567891", "email": "henryjohnson@example.com"},
{"nama": "Heru Wibowo", "telp": "086294871843", "email": "heruwibowo@example.com"},
{"nama": "Humaira", "telp": "085476543291", "email": "humaira@example.com"},
{"nama": "Ida Ayu Putri", "telp": "087534098151", "email": "idaayuputri@example.com"},
{"nama": "Ika Novita", "telp": "089769473186", "email": "ikanovita@example.com"},
{"nama": "Inka Ushmila", "telp": "083154279107", "email": "inkaushmila@example.com"},
{"nama": "Irin Bella", "telp": "082309458142", "email": "irinbella@example.com"},
{"nama": "Irma Setyawati", "telp": "081234126176", "email": "irmasetyawati@example.com"},
{"nama": "Isabella Johnson", "telp": "096891234567", "email": "isabellajohnson@example.com"},
{"nama": "Jack Wilson", "telp": "130478912345", "email": "jackwilson@example.com"},
{"nama": "Jaka Arish", "telp": "08643572124", "email": "jakarish@example.com"},
{"nama": "James Brown", "telp": "128256789123", "email": "jamesbrown@example.com"},
{"nama": "James Johnson", "telp": "105891234567", "email": "jamesjohnson@example.com"},
{"nama": "Jane Smith", "telp": "082345678912", "email": "janesmith@example.com"},
{"nama": "Jessica Taylor", "telp": "086789123456", "email": "jessicataylor@example.com"},
{"nama": "Jihan Melia", "telp": "082212232000", "email": "jihanmelia@example.com"},
{"nama": "John Doe", "telp": "081234567891", "email": "johndoe@example.com"},
{"nama": "Joko Prabowo", "telp": "083765490159", "email": "jokoprabowo@example.com"},
{"nama": "Joseph Anderson", "telp": "097912345678", "email": "josephanderson@example.com"},
{"nama": "Joseph Anderson", "telp": "115912345678", "email": "josephanderson@example.com"},
{"nama": "Juan Atharizz", "telp": "08695843126", "email": "juanatharizz@example.com"},
{"nama": "Julian", "telp": "086759643217", "email": "julian@example.com"},
{"nama": "Juliyasti", "telp": "086523148108", "email": "juliyasti@example.com"},
{"nama": "Kafin Jayanegara", "telp": "087612345689", "email": "jayanegara@example.com"},
{"nama": "Kenasatya", "telp": "084328674134", "email": "kenasatya@example.com"},
{"nama": "Kenzo Auger", "telp": "08764619128", "email": "kenzoauger@example.com"},
{"nama": "Key Faldian", "telp": "085643629143", "email": "keyfaldian@example.com"},
{"nama": "Kirei Aruan", "telp": "08563892125", "email": "kireiaruan@example.com"},
{"nama": "Leo Tanjuang", "telp": "087654739148", "email": "leotanjung@example.com"},
{"nama": "Liam Davis", "telp": "120467891234", "email": "liamdavis@example.com"},
{"nama": "Lily Johnson", "telp": "117134567891", "email": "lilyjohnson@example.com"},
{"nama": "Lina Purnama", "telp": "087968493182", "email": "linapurnama@example.com"},
{"nama": "Lola Nalini", "telp": "081654237697", "email": "lolanalini@example.com"},
{"nama": "Lucas Smith", "telp": "116023456789", "email": "lucassmith@example.com"},
{"nama": "Maliqa", "telp": "083844315110", "email": "maliqa@example.com"},
{"nama": "Martha", "telp": "08342165114", "email": "martha@example.com"},
{"nama": "Matthew Thomas", "telp": "091345678912", "email": "matthewthomas@example.com"},
{"nama": "Mawaddah", "telp": "085423457688", "email": "mawaddah@example.com"},
{"nama": "Maya Baayan", "telp": "082376458129", "email": "mayabaayan@example.com"},
{"nama": "Maya Dewi", "telp": "085439067158", "email": "mayadewi@example.com"},
{"nama": "Maya Sari", "telp": "086978543194", "email": "mayasari@example.com"},
{"nama": "Meera Aruna", "telp": "097865431290", "email": "meeraaruna@example.com"},
{"nama": "Mega Putri", "telp": "10345678901", "email": "mega@example.com"},
{"nama": "Mia Brown", "telp": "108234567891", "email": "miabrown@example.com"},
{"nama": "Mia Rodriguez", "telp": "134823456789", "email": "miarodriguez@example.com"},
{"nama": "Mia Taylor", "telp": "098123456789", "email": "miataylor@example.com"},
{"nama": "Michael Johnson", "telp": "083456789123", "email": "michaeljohnson@example.com"},
{"nama": "Minara Isha", "telp": "085632142299", "email": "minaraisha@example.com"},
{"nama": "Mulyono Siregar", "telp": "089769584181", "email": "mulyonosiregar@example.com"},
{"nama": "Nita Utami", "telp": "081234525165", "email": "nitautami@example.com"},
{"nama": "Noah Williams", "telp": "118245678912", "email": "noahwilliams@example.com"},
{"nama": "Nurul Hidayah", "telp": "086406780155", "email": "nurulhidayah@example.com"},
{"nama": "Olivia Davis", "telp": "112678912345", "email": "oliviadavis@example.com"},
{"nama": "Olivia Martinez", "telp": "088912345678", "email": "oliviamartinez@example.com"},
{"nama": "Olivia Taylor", "telp": "123791234567", "email": "oliviataylor@example.com"},
{"nama": "Oman Binarma", "telp": "083256657778", "email": "binarmaoman@example.com"},
{"nama": "Ratnasari", "telp": "081943219081", "email": "ratnasarii@example.com"},
{"nama": "Ratna Purnama", "telp": "089901234567", "email": "ratnapurnama@example.com"},
{"nama": "Rayyan Malik", "telp": "081923457683", "email": "malikrayyan@example.com"},
{"nama": "Rehan Omar", "telp": "087854324080", "email": "omarrehan@example.com"},
{"nama": "Rendra Utas", "telp": "087820195176", "email": "utasrendra@example.com"},
{"nama": "Rengganis", "telp": "08584321119", "email": "rengganis@example.com"},
{"nama": "Retno Puspita", "telp": "086290342168", "email": "retnopuspita@example.com"},
{"nama": "Rina Aulia", "telp": "10123456789", "email": "rinaaulia@example.com"},
{"nama": "Rina Setiawati", "telp": "08497658192", "email": "rinasetiawati@example.com"},
{"nama": "Rini Handayani", "telp": "082431569170", "email": "rinihandayani@example.com"},
{"nama": "Rini Wulandari", "telp": "084638766161", "email": "riniwulandari@example.com"},
{"nama": "Rizal Ibrahim", "telp": "083546786191", "email": "rizalibrahim@example.com"},
{"nama": "Rizki Pratama", "telp": "083426531166", "email": "rizkipratama@example.com"},
{"nama": "Rudi Hermawan", "telp": "084326781190", "email": "rudihermawan@example.com"},
{"nama": "Rudi Wibowo", "telp": "09901234567", "email": "rudi@example.com"},
{"nama": "Robby Kusuma", "telp": "10456789012", "email": "robby@example.com"},
{"nama": "Sarah Williams", "telp": "084567891234", "email": "sarahwilliams@example.com"},
{"nama": "Sennaelok", "telp": "087658430144", "email": "sennaelok@example.com"},
{"nama": "Siti Rahayu", "telp": "086978540192", "email": "sitirahayu@example.com"},
{"nama": "Siti Rahayu", "telp": "089745609153", "email": "sitirahayu@example.com"},
{"nama": "Surya Wijaya", "telp": "084967501185", "email": "suryawijaya@example.com"},
{"nama": "Susi Rahmawati", "telp": "084586740180", "email": "susirahmawati@example.com"},
{"nama": "Sophia Anderson", "telp": "127145678912", "email": "sophiaanderson@example.com"},
{"nama": "Sophia Davis", "telp": "094678912345", "email": "sophiadavis@example.com"},
{"nama": "Sophia Johnson", "telp": "114891234567", "email": "sophiajohnson@example.com"},
{"nama": "Tara Masayu", "telp": "085436786133", "email": "taramasayu@example.com"},
{"nama": "Teguh Kusuma", "telp": "085476586173", "email": "teguhkusuma@example.com"},
{"nama": "Tibra Prawara", "telp": "082843786106", "email": "tibraprawara@example.com"},
{"nama": "Tri Utami", "telp": "089789012345", "email": "triutami@example.com"},
{"nama": "Tri Wulandari", "telp": "084876508195", "email": "triwulandari@example.com"},
{"nama": "Umar Wastu", "telp": "08342532104", "email": "umarwastu@example.com"},
{"nama": "Yanti Susanti", "telp": "081234525165", "email": "yantisusanti@example.com"},
{"nama": "Yasawirya", "telp": "081356782102", "email": "yasawirya@example.com"},
{"nama": "Yazid Xavier", "telp": "082365474109", "email": "yazidxavier@example.com"},
{"nama": "Yulia Sari", "telp": "086754328164", "email": "yuliasari@example.com"},
{"nama": "Yuli Susanti", "telp": "089567890123", "email": "yulisusanti@example.com"},
{"nama": "Yumna Naladhipa", "telp": "114891234567", "email": "yumnanaladhipa@example.com"},
{"nama": "Yuniarti Wijaya", "telp": "089123456789", "email": "yuniartiwijaya@example.com"},
{"nama": "Yura Dara", "telp": "087654933149", "email": "yuradara@example.com"},
{"nama": "Yola Siregar", "telp": "086975437146", "email": "yolasiregar@example.com"},
{"nama": "Pietro Zayyan", "telp": "08543621117", "email": "pietrozayyan@example.com"},
{"nama": "William Garcia", "telp": "111567891234", "email": "williamgarcia@example.com"},
{"nama": "William Rodriguez", "telp": "095789123456", "email": "williamrodriguez@example.com"},
{"nama": "Wulan Sari", "telp": "087865471999", "email": "wulansari@example.com"},
]


nama_cari = input("Masukkan nama yang ingin dicari: ")
hasil_pencarian = binary_search(contacts, nama_cari)

if hasil_pencarian:
    print("Data kontak ditemukan:")
    print("Nama:", hasil_pencarian["nama"])
    print("Telepon:", hasil_pencarian["telp"])
    print("Email:", hasil_pencarian["email"])
else:
    print("Data kontak tidak ditemukan.")