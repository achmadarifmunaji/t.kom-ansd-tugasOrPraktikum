def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

# Input dari pengguna
n = int(input("Masukkan nilai n untuk menghitung faktorial (n!): "))

if n < 0:
    print("Faktorial tidak tersedia untuk nilai negatif.")
else:
    result = factorial(n)
    print(f"{n}! = {result}")
