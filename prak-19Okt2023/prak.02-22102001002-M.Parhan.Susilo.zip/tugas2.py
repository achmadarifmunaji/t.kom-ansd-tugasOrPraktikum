class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return len(self.items) == 0

    def enqueue(self, item):
        self.items.append(item)

    def dequeue(self):
        if not self.is_empty():
            return self.items.pop(0)
        else:
            print("Antrian sudah kosong.")
            return None

    def size(self):
        return len(self.items)

if __name__ == "__main__":
    antrian = Queue()

    # Masukkan 3 nama ke dalam antrian
    antrian.enqueue("Iqbal")
    antrian.enqueue("Riski")
    antrian.enqueue("Raita")

    print("Antrian pertama: ", antrian.items[0])
    print("Antrian terakhir: ", antrian.items[-1])

    # Keluarkan Iqbal dan Riski dari antrian
    antrian.dequeue()
    antrian.dequeue()

    # Masukkan Yusron dan Arlianto ke dalam antrian
    antrian.enqueue("Yusron")
    antrian.enqueue("Arlianto")

    print("Antrian pertama: ", antrian.items[0])
    print("Antrian terakhir: ", antrian.items[-1])
