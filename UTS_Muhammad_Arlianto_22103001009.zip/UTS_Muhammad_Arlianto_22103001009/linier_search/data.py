import time, csv
start_time = time.time()
def read_csv_file(file_path):
    data = []
    try:
        with open(file_path, 'r', newline='') as file:
            csv_reader = csv.reader(file)
            for row in csv_reader:
                data.append(row)
        return data
    except FileNotFoundError:
        print(f"File '{file_path}' not found.")
    except Exception as e:
        print(f"Something wrong: {str(e)}")
    return None

def linier_search(arr, target):
    for i in range(len(arr)):
        # print (i)
        if arr[i] == target:
            return i #element found, back index
    return -1 #element not found

file_path = 'linier_search\employee_data.csv'
csv_data = read_csv_file(file_path)
jumlah_data = len(csv_data)
arr = sum(csv_data, [])
target = 'BPC'
data_search = linier_search(arr, target)
end_time = time.time()
execution_time = end_time - start_time
print(arr)
print(jumlah_data)
print (f"Target is find on {data_search}")
print (f"Execution find in: {execution_time} Second",)