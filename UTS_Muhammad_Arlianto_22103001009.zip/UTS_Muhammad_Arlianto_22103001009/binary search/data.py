import time, csv 
start_time = time.time()
def read_csv_file(file_path):
    data = []
    try:
        with open(file_path, 'r', newline='') as file:
            csv_reader = csv.reader(file)
            next(csv_reader)
            for row in csv_reader:
                data.append(row[0])
        return data
    except FileNotFoundError:
        print(f"File '{file_path}' not found.")
    except Exception as e:
        print(f"Somethin error: {str(e)}")
    return None

def binary_search(arr, target):
    left, right =0, len(arr)-1
    while left <= right:
        mid = (left + right)//2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1

file_path = 'binary search/employee_data.csv'
csv_data = read_csv_file(file_path)
arr = csv_data
target = '3121'
data_search = binary_search(arr, target)
end_time = time.time()
execution_time = end_time - start_time
print (f"Target is find on {data_search}")
print (f"Execution find in: {execution_time} Second",)