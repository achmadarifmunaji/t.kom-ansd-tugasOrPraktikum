class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

#Pencarian Elemen Terkecil di Pohon: Buat program yang mencari elemen terkecil dalam pohon biner.
def find_minimum(node):
    if node is None:
        return float('inf')  # Return positive infinity for an empty tree
    else:
        return min(node.value, find_minimum(node.left), find_minimum(node.right))

#Hitung Jumlah Daun: Buat program yang menghitung jumlah daun (simpul tanpa anak) dalam pohon biner.
def count_leaves(node):
    if node is None:
        return 0
    elif node.left is None and node.right is None:
        return 1
    else:
        return count_leaves(node.left) + count_leaves(node.right)

# Buat pohon biner
pohon = Node(10)
pohon.left = Node(5)
pohon.right = Node(15)
pohon.left.left = Node(3)
pohon.left.right = Node(7)
pohon.right.left = Node(12)
pohon.right.right = Node(18)

# Cari elemen terkecil
minimum = find_minimum(pohon)
print(f"Elemen terkecil dalam pohon biner adalah: {minimum}")

# Contoh penggunaan
# Menggunakan pohon yang sama dari contoh sebelumnya
jumlah_daun = count_leaves(pohon)
print(f"Jumlah daun dalam pohon biner adalah: {jumlah_daun}")

#Bilangan Fibonacci dalam Pohon: Buat pohon biner yang mewakili bilangan Fibonacci 
#dan tuliskan algoritma untuk menghitung bilangan Fibonacci ke-n menggunakan pohon tersebut.
class FibonacciNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def build_fibonacci_tree(n):
    if n <= 1:
        return FibonacciNode(n)
    else:
        root = FibonacciNode(n)
        root.left = build_fibonacci_tree(n - 1)
        root.right = build_fibonacci_tree(n - 2)
        return root

def calculate_fibonacci(node):
    if node is None:
        return 0
    elif node.value <= 1:
        return node.value
    else:
        return calculate_fibonacci(node.left) + calculate_fibonacci(node.right)

n = 10  # Ganti nilai n sesuai dengan indeks bilangan Fibonacci yang diinginkan
pohon_fibonacci = build_fibonacci_tree(n)
hasil_fibonacci = calculate_fibonacci(pohon_fibonacci)
print(f"Bilangan Fibonacci ke-{n} adalah: {hasil_fibonacci}")

