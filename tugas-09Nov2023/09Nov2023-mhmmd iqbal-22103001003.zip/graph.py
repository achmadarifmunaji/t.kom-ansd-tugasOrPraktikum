# Buat Graf Sederhana: Buat graf sederhana dengan beberapa simpul dan 
# tepatkan beberapa sisi yang menghubungkannya.
class Graf:
    def __init__(self):
        self.simpul = set()
        self.sisi = []

    def tambah_simpul(self, simpul):
        self.simpul.add(simpul)

    def tambah_sisi(self, simpul1, simpul2):
        self.sisi.append((simpul1, simpul2))

# Hitung Jumlah Simpul dan Sisi: Buat program yang 
# menghitung jumlah simpul dan sisi dalam graf yang telah Anda buat.
    def hitung_jumlah_simpul(self):
        return len(self.simpul)

    def hitung_jumlah_sisi(self):
        return len(self.sisi)

# Cek Keterhubungan: Buat program yang memeriksa apakah graf yang Anda buat 
# terhubung atau memiliki beberapa komponen terhubung yang terisolasi.
    def cek_keterhubungan(self):
        daftar_keterhubungan = {}
        for sisi in self.sisi:
            (simpul1, simpul2) = sisi
            daftar_keterhubungan.setdefault(simpul1, set()).add(simpul2)
            daftar_keterhubungan.setdefault(simpul2, set()).add(simpul1)

        simpul_terhubung = set()
        stack = [next(iter(self.simpul))]
        while stack:
            simpul = stack.pop()
            if simpul not in simpul_terhubung:
                simpul_terhubung.add(simpul)
                stack.extend(daftar_keterhubungan[simpul] - simpul_terhubung)

        return len(simpul_terhubung) == len(self.simpul)


# Contoh penggunaan
graf_saya = Graf()
graf_saya.tambah_simpul("Farhan")
graf_saya.tambah_simpul("Rizki")
graf_saya.tambah_simpul("Raita")
graf_saya.tambah_simpul("Nely")

graf_saya.tambah_sisi("farhan", "Rizki")
graf_saya.tambah_sisi("Rizki", "Raita")
graf_saya.tambah_sisi("Raita", "Nely")

print(f"Jumlah Simpul: {graf_saya.hitung_jumlah_simpul()}")
print(f"Jumlah Sisi: {graf_saya.hitung_jumlah_sisi()}")
print(f"Keterhubungan: {graf_saya.cek_keterhubungan()}")
