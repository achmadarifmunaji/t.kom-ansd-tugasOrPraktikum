import heapq

def dijkstra(graph, start):
    # Inisialisasi jarak dengan tak terhingga
    distances = {node: float('infinity') for node in graph}
    distances[start] = 0
    
    # Prioritas antrian untuk menyimpan node yang akan dikunjungi
    priority_queue = [(0, start)]
    
    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)
        
        # Jika jarak saat ini lebih besar dari yang sudah dihitung, abaikan
        if current_distance > distances[current_node]:
            continue
        
        # Perbarui jarak ke tetangganya
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))
    
    return distances

# Representasi graf berbobot dalam bentuk dictionary
graph = {
    'A': {'B': 6, 'D': 1},
    'B': {'A': 6, 'D': 2, 'E': 2, 'C': 5},
    'C': {'B': 5, 'E': 5},
    'D': {'A': 1, 'B': 2, 'E': 1},
    'E': {'B': 2, 'C': 5, 'D': 1}
}

start_node = 'A'
result = dijkstra(graph, start_node)

# Tampilkan hasil
for node, distance in result.items():
    print(f"Jarak dari {start_node} ke {node}: {distance} km")