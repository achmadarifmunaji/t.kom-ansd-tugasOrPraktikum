class stack :
    def __init__(self):
        self.item = []

    def is_empty(self) :
        return len(self.item) == 0
    
    def push(self,item) :
        self.item.append(item)

    def pop(self) :
        if not self.is_empty() :
            return self.item.pop()
        else :
            return None
    
    def peek(self) :
        if not self.is_empty() :
            return self.item[-1]
        else :
            return None
        
    def size(self) :
        return len(self.item)
    

my_stack = stack()
my_stack.push("Arifin")
my_stack.push(2)


print(my_stack.size())
print(my_stack.is_empty())
print(my_stack.peek())
print(my_stack.pop())


class Mahasiswa :
    def __init__(self, nama, nim, usia) :
        self.nama = nama
        self.nim = nim
        self.usia = usia

    def __str__(self) :
        return f"{self.nama} {self.nim} {self.usia}"
    

class  StackMahasiswa :
    def __init__(self) :
        self.mahasiswa_stack = []
    
    def push(self, mahasiswa):
        self.mahasiswa_stack.append(mahasiswa)

    def pop(self) :
        if not self.is_empty():
            return self.mahasiswa_stack.pop()
        else :
            return None
        
    def peek(self) :
        if not self.is_empty():
            return self.mahasiswa_stack[-1]
        else :
            return None
        
    def is_empty(self) :
        return len(self.mahasiswa_stack) == 0
    
    def size(self) :
        return len(self.item)
    
    def __str__(self) :
        return ", " .join(str(mahasiswa) for mahasiswa in self.mahasiswa_stack)
    


stack_mahasiswa = StackMahasiswa()

mahasiswa1 = Mahasiswa("Yusran", "22103001006", "19")
mahasiswa2 = Mahasiswa("Farhan", "22103001002", "25")

stack_mahasiswa.push(mahasiswa1)
stack_mahasiswa.push(mahasiswa2)
stack_mahasiswa.pop()
stack_mahasiswa.is_empty()
stack_mahasiswa.peek()

print("Daftar Mahasiswa :")
print(stack_mahasiswa)