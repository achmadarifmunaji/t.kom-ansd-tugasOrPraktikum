# class Mobil:
#     def __init__(self, merek, model, TahunProduksi, harga):
#         self.merek = merek
#         self.model = model 
#         self.TahunProduksi = TahunProduksi
#         self.harga = harga 

#     def info(self):
#         print("Mobil:", self.merek)
#         print("Model:", self.model)
#         print("TahunProduksi:", self.TahunProduksi)
#         print("Harga:", self.harga)

# Mobil1 = Mobil("avanza","baru",2021,"Rp 230.000.000")
# Mobil2 = Mobil("honda","lama",2017,"Rp 430.000.000")
# Mobil3 = Mobil("yamaha","baru",2018,"Rp 140.000.000")

# Mobil1.info()
# print(".....")
# Mobil2.info()
# print(".....")
# Mobil3.info()



# class Mahasiswa:
#     def __init__(self, nama, usia, jurusan):
#         self.nama = nama
#         self.usia = usia
#         self.jurusan = jurusan
#     def info(self):
#         print("nama:",self.nama)
#         print("usia:",self.usia)
#         print("jurusan:",self.jurusan)

# Mahasiswa1 = Mahasiswa("andre",22,"teknik")
# Mahasiswa2 = Mahasiswa("rahmad",23,"ekonomi")
# Mahasiswa3 = Mahasiswa("angga",21,"agama")

# Mahasiswa1.info()
# print("....")
# Mahasiswa2.info()
# print("....")
# Mahasiswa3.info()



# class Buku:
#     def __init__(self, judul, penulis, tahun_terbit, harga):
#         self.judul = judul
#         self.penulis = penulis
#         self.tahun_terbit = tahun_terbit
#         self.harga = harga
#     def info(self):
#         print("judul:",self.judul)
#         print("penulis:",self.penulis)
#         print("tahun terbit:",self.tahun_terbit)
#         print("harga:",self.harga)

# Buku1 = Buku("matematika","rangga",2019,"Rp 23.000")
# Buku2 = Buku("ips","adit",2023,"Rp 43.000")
# Buku3 = Buku("ipa","rahma",2018,"Rp 14.000")

# Buku1.info()
# print("....")
# Buku2.info()
# print("....")
# Buku3.info()



class Mahasiswa:
    def __init__(self, nama, usia, jurusan):
        self.nama = nama
        self.usia = usia
        self.jurusan = jurusan
    def info(self):
        print("nama:",self.nama)
        print("usia:",self.usia)
        print("jurusan:",self.jurusan)

mahasiswa1 = Mahasiswa("andre", 22, "teknik")
mahasiswa2 = Mahasiswa("rahmad", 23, "ekonomi")
mahasiswa3 = Mahasiswa("angga", 21, "agama")

daftar_mahasiswa = [mahasiswa1, mahasiswa2, mahasiswa3]
for mahasiswa in daftar_mahasiswa:
    mahasiswa.info()
    print("...")
