class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insert_at_beginning(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def delete_at_end(self):
        if not self.head:
            return

        if not self.head.next:
            self.head = None
            return

        current = self.head
        while current.next.next:
            current = current.next

        current.next = None

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

# Contoh penggunaan:
linked_list = LinkedList()
linked_list.insert_at_beginning(111)
linked_list.insert_at_beginning(99)
linked_list.insert_at_beginning(88)
linked_list.insert_at_beginning(77)
linked_list.insert_at_beginning(66)
linked_list.insert_at_beginning(55)

print("Isi Linked List:")
linked_list.display()

linked_list.delete_at_end()

print("Linked List setelah menghapus elemen terakhir:")
linked_list.display()
