[1]
class LinkedList:
    def __init__(self) :
    self.head = None

    def is_empty (self) :
    return self.head is None  

    def append(self,data) :
    new_node = Node (data)
    if self.is_empty():
    self.head = new_node

    else :
current = self.head
while current.next_node:
    current = current.nex_node
    current.next_node = new_node

linked_list = LinkedList()
link_list.append(2)
link_list.append(2)
link_list.append(1)
link_list.append(2)

def display(self) :
    elements = []
    current = self.head
    while current :
        elements.append(current.data)
        current = current.next_node
    print("->".join(map(str, elements)))

linked_list.display()
linked_list.delete_at_end()
print("____________________________")
linked_list.display()
print("____________________________")

[2]
class Mobil:
    def __init__(self, nama, merk, tahun):
        self.nama = nama
        self.merk = merk
        self.tahun = tahun

class LinkedList:
    def __init__(self):
        self.head = None
    def jenis_mobil(self, nama, merk, tahun):
        versi_mobil = Mobil(nama, merk, tahun)
        if self.head is None:
            self.head = tampilkan_mobil
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = jenis_mobil
    def tampilkan_mobil(self):
        current = self.head
        while current:
            print(f"Nama: {current.nama}, Merk: {current.merk}, Tahun: {current.tahun}")
            current = current.next

linked_list = LinkedList()
linked_list.jenis_mobil("Toyota", "Avanza", "2021")
linked_list.jenis_mobil("Honda", "Civic", "2022")
linked_list.jenis_mobil("Suzuki", "Ertiga", "2021")
linked_list.tampilkan_mobil()
print("________________________________________")
